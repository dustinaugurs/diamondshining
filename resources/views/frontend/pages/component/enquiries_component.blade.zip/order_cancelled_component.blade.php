
                                <!-- product single item start -->
<div class="table-responsive">
 
 <table class="table table-bordered" style="border-collapse:collapse;">
 <caption>{{$cancelled}}</caption>
<thead>
<tr>
<th>Date 
        <div class="changedatabox">
            <select name="changedate" id="changedate">
            <option value="00_00">All</option>    
            <?php
            $dateTime = new DateTime('first day of this month');
            for ($i = 1; $i <= 56; $i++) {
            echo '<option value="'.$dateTime->format('m_Y').'">'.$dateTime->format('M-y').'</option>';
            $dateTime->modify('-1 month');
            }
            ?>
            </select>
        </div>
    </th>
    <th>Ref/Name/Contact No.</th>
    <th>Order Status</th>
    <th>Items</th>
    <th>Cost (Ex VAT)</th>
    <th>Multiplier</th>
    <th>SalePrice (Ex VAT)</th>
    <th>SalePrice (Inc VAT)</th>
    <th>Payment Status
    <div class="changedatabox">
            <select name="payment_status" id="">
                <option value="">All</option>
                <option value="">Deposite Paid</option>
                <option value="">Fully Paid</option>
            </select>
        </div>
    </th>
    <th>ETA</th>
</tr>
 </thead>
 <tbody>
 
<tr>
<td>16/07/2020 7:11 AM</td>
<td class="reftd">&nbsp;</td>


<td>Order Request
<a href="javascript">Change</a>
</td>

<td><a class="view_diamond" data-id="6156" target="_blank" href="js;">WL16UIFSEYWDZ3GG</a>

<td>Enquiry</td>
</td>
<td class="admin costs" style="display: table-cell;">£192.85</td>
<td class="no-show costs" style="display: table-cell;">1.400x</td>
<td class="no-show-admin">£269.99</td>
<td>Pending
    <a href="javascript">Change</a>
</td>
<td class="no-show-admin">29/07/2020</td>
</tr>

                                  

</tbody>
</table> 

</div>
							 
							 	 
							 
							 
							 