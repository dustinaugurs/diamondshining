<p class="small center" style="line-height: 24px; margin-bottom: 20px;">
    ©{{date('Y')}} <a href="{{ url('/') }}" target="_blank" class="lap">@yield('title', app_name())</a>
    All Rights are Reserved.
</p>